package com.jiyeon.project.service;

import com.jiyeon.project.domain.Role;
import com.jiyeon.project.domain.User;
import com.jiyeon.project.repository.RoleRepository;
import com.jiyeon.project.repository.UserRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class UserServiceImpl implements UserService{

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;

    @Override
    public User saveUser(User user) {
        log.info("saving user");
        return userRepository.save(user);
    }

    @Override
    public Role saveRole(Role role) {
        log.info("saving role database");
        return roleRepository.save(role);
    }

    @Override
    public void addRoleToUser(Long userId, String roleName) {
        User user = userRepository.findByUserId(userId).get();
        Role role = roleRepository.findByName(roleName);
        user.getRole().add(role);
    }

    @Override
    public User getUser(String username) {
        return null;
    }

    @Override
    public List<User> getUsers() {
        return null;
    }
}
