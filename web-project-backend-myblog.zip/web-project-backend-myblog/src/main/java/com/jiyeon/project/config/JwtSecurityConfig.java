package com.jiyeon.project.config;

import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

public class JwtSecurityConfig extends WebSecurityConfigurerAdapter {

}
