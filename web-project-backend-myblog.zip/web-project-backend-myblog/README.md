# myblog

- Java 11
- Maven
- JPA
- mongodb
- Kafka

일단 간단한 부분만 끝까지 배포하고 수정하는 형태로 
